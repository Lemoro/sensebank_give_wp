<?php
    /**
     * This filter hook is used to add configuration fields like api key, access token, oAuth button, etc.
     *
     * @since 2.5.0
     *
     * @return array
     */
    $settings = apply_filters( 'give_sensebank_add_configuration_fields', $settings );

    // $settings['test'][] = [
    //         'id'   => 'give_title_stripe_sepa',
    //         'type' => 'title',
    //       ];

          $settings['test'][] = [
            'name'          => esc_html__( 'Test mode', 'sensebank-give' ),
            'desc'          => __( 'This option allows you to enable the test mode of payment by bank card. A <a href="https://portal.sensebank.com.ua/mportal/#/docs/page/2">page</a> with text details.', 'sensebank-give' ),
            'id'            => 'test_mode_radio',
            'wrapper_class' => 'test_mode_radio',
            'type'          => 'radio_inline',
            'default'       => 'enabled',
            'options'       => [
              'enabled'  => esc_html__( 'Enabled', 'sensebank-give' ),
              'disabled' => esc_html__( 'Disabled', 'sensebank-give' ),
            ],
          ];