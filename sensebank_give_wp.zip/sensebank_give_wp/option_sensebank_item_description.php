<?php
    /**
     * This filter hook is used to add configuration fields like api key, access token, oAuth button, etc.
     *
     * @since 2.5.0
     *
     * @return array
     */
    $settings = apply_filters( 'give_sensebank_add_configuration_fields', $settings );

    $settings['general'][] = [
      'name'          => esc_html__( 'Sensebank Item Description', 'sensebank-give' ),
      'desc'          => '',
      'wrapper_class' => 'give-sensebank-webhooks-tr',
      'id'            => 'sensebank_itemdescription',
      'type'          => 'sensebank_itemdescription',
    ];

    $settings['general'][] = [
      'name' => esc_html__( 'Sensebank Item Description', 'sensebank-give' ),
      'desc' => esc_html__( 'Enter a short description of the payment in this field', 'sensebank-give' ),
      'id'   => 'sensebank_item_description',
      'type' => 'text',
    ];