<?php
// namespace Plagin\Sensebank\Class;


class MiddlewareSensebank{

  /**
   * [$merchant_id description]
   * @var integer
   */
  private static $merchant_id=1435487;
  /**
   * [$password description]
   * @var string
   */
  private static $password='test';

  private static $item_description='';

  private static function setItemDescriptionTest($item_description){
    self::$item_description=$item_description.",ID: ".$_GET['m_payment_id'];
  }
  /**
   *
   */
  public static function getOptions(){

    if(give_get_option( 'test_mode_radio' )=='enabled') {
      self::setItemDescriptionTest(__('Test mode/Test payment', 'sensebank-give'));
      return;
    }
    self::$merchant_id = give_get_option( 'sensebank_merchantid' )??self::$merchant_id;
    self::$password = give_get_option( 'sensebank_paykey' )??self::$password;
    self::$item_description = give_get_option( 'sensebank_itemdescription' )??$_GET['item_description'];
  }
  /**
   * [postRequest description]
   * @return [type] [description]
   */
  public static function postRequest(){
    self::getOptions();
    $data = self::buildDataFinal();
    echo  self::steCurl($data);
    // var_dump($data);
  }
  /**
   * [steCurl description]
   * @param  [type] $postfields [description]
   * @return [type]             [description]
   */
  private static function steCurl($postfields){
    $curl = curl_init('https://payments.sensebank.com.ua/api/checkout/redirect/');
    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
    curl_setopt($curl, CURLOPT_POSTFIELDS, $postfields);
    // Принимаем в виде массива. (false - в виде объекта)
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_POSTFIELDS, $postfields);
    curl_setopt($curl, CURLOPT_HTTPHEADER, [
      'Mozilla/5.0 (X11; Linux x86_64; Twisted) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.108 Safari/537.36',
    ]);
    $result = curl_exec($curl);
    curl_close($curl);
    return $result;
  }
  /**
   * [setDataStart description]
   */
  private static function setDataStart(){
    return [
        "server_callback_url"=>"https://dev.welfare.green/sensebank/callback",
        "response_url"=>"https://dev.welfare.green/sensebank/response",
        "order_id"=>$_GET['m_payment_id'],
        "order_desc"=>self::$item_description,
        "currency"=>"UAH",
        "amount"=>(int)$_GET['amount'],

        // "payment_systems"=>"card",
        "merchant_id"=>self::$merchant_id,
      ];
  }
  /**
   * [buildDataFinal description]
   * @return [type] [description]
   */
  private static function buildDataFinal(){
    include 'class-signature-sensebank.php';


    Signature::password(self::$password);
    Signature::merchant(self::$merchant_id);
    return Signature::sign(self::setDataStart());
  }
}