<?php
/**
 * Plugin Name: Sensebank Gateway for GiveWP
 * Description: Sensebank Gateway for GiveWP
 * Version: 0.1.2
 * Requires at least: 5.0
 * Requires PHP: 7.0
 * Author: Lemoro
 * Author URI: https://github.com/Lemoro
 * Text Domain: sensebank-give
 * Domain Path: /languages
 */

/**
 * подключение папки с файлами языков перевода
 */
add_action( 'plugins_loaded', 'myplugin_init' );
function myplugin_init() {
   load_plugin_textdomain( 'sensebank-give', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
}

/**
 * проверка наличия установленного плагина GiveWP
 */
if (! in_array( 'give/give.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
  add_action('shutdown', 'general_admin_notice');
return;
}
/**
 * вывод ошибки в случае отсутствия установленного плагина GiveWP
 * @return [type] [description]
 */
function general_admin_notice(){
    global $pagenow;
    if ( $pagenow == 'plugins.php' ) {
         echo( '<div class="notice notice-error is-dismissible" data-dismissible="1">
             <p>'.__('For the "Sensebank Gateway for GiveWP" plugin to work correctly, you need to install the plugin: https://givewp.com/', 'sensebank-give').'</p>
         </div>');
    }
}


/**
 * обработка ответа от сервера банка в случае удачного платежа
 */
add_action( 'template_redirect', function() {
    if ( preg_match( '#^/sensebank\/response\/?#i', $_SERVER['REQUEST_URI'] ) ) {

        include __DIR__.'/class_response_sensebank.php';
        ResponseSensebank::setStatusDonation();
        wp_redirect( '/donation-confirmation/');
        exit;
    }
} );
/**
 * обработка ответа от сервера банка в случае ошибки платежа
 */
add_action( 'template_redirect', function() {
    if ( preg_match( '#^/sensebank\/callback\/?#i', $_SERVER['REQUEST_URI'] ) ) {

      $callback = $_POST;
      file_put_contents('collbak_save', json_encode($callback));

      wp_redirect( '/donation-failed/');
      exit;
    }
} );

/*
подключение класса подготовки данных для отправки на сервер банка
 */
add_action('givewp_register_payment_gateway', static function ($paymentGatewayRegister) {
    include 'class-offsite-sensebank-gateway.php';
    $paymentGatewayRegister->registerGateway(SensebankGatewayOffsiteClass::class);
});
/*
подключение класса формирования POST запроса
 */
add_action( 'template_redirect', function() {
    if ( preg_match( '#^/sensebank\/redirect\/?#i', $_SERVER['REQUEST_URI'] ) ) {
        include __DIR__.'/class-middleware-sensebank.php';
        MiddlewareSensebank::postRequest();
        exit;
    }
});
/*
зоздание ссылки под названием плагина в списке установленных плагинов
 */
add_filter( 'plugin_action_links', function($links, $file){

    if ( $file != plugin_basename(__FILE__) ){
        return $links;
    }

    $settings_link = sprintf('<a href="%s">%s</a>', 'edit.php?post_type=give_forms&page=give-settings&tab=gateways&section=sensebank-settings', __('Settings','sensebank-give'));

    array_unshift( $links, $settings_link );
    return $links;
}, 10, 2 );


/**
 * [register_sections добавление секции в блок настроек плагина GiveWP]
 * @param  [type] $sections [description]
 * @return [type]           [description]
 */
function register_sections($sections  ) {
      $sections['sensebank-settings'] = __( 'Sensebank', 'give' );
      return $sections;
}
add_filter( 'give_get_sections_gateways', 'register_sections', 1 );
/**
 * [register_groups добавление групп в секию настроек]
 * @return [type] [description]
 */
function register_groups() {
      $groups = [
        'general'     => __( 'General Settings', 'sensebank-give' ),
        'test'        => __( 'Test mode', 'sensebank-give'),
      ];
      return apply_filters( 'give_sensebank_register_groups', $groups );
    }
add_filter( 'give_get_groups_sensebank-settings', 'register_groups');


/**
 * [register_settings добавление опций в группы настроек]
 * @param  [type] $settings [description]
 * @return [type]           [description]
 */
function register_settings( $settings ){
  $section = give_get_current_setting_section();
  if('sensebank-settings'==$section){
    $settings['general'][] = [
      'id'   => 'give_title_sensebank_general',
      'type' => 'title',
    ];

    include 'options-sensebank-key.php';
    include 'options-sensebank-marchant.php';
    include 'option_sensebank_item_description.php';
    include 'option_sensebank_test_mode.php';

    $settings['general'][] = [
      'id'   => 'give_title_sensebank_general',
      'type' => 'sectionend',
    ];
  }


return $settings;
}
add_filter( 'give_get_settings_gateways', 'register_settings');


