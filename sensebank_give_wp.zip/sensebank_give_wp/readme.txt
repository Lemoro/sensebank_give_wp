=== Sensebank GiveWP ===
Contributors: Lemoro
Tags: donations, donation, fundraising, fundraiser, gateway, sensebank
Requires at least: 5.0
Tested up to: 6.1
Stable tag: 0.1.1
Requires Give: 2.24.0
Requires PHP: 7.0
License: GPLv3
License URI: https://opensource.org/licenses/GPL-3.0

Sensebank Gateway for GiveWP

== Description ==

This plugin requires the GiveWP core plugin activated to function properly.

== Installation ==

