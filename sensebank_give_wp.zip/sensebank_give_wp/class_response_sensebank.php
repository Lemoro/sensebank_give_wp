<?php

/**
 *
 */
class ResponseSensebank
{
  /**
   * [$status description]
   * @var string
   */
  private static $status="cancelled";

  private static $statusArray =[
    'approved'=>"publish",

  ];
  /**
   * [setStatusDonation description]
   */
  public static function setStatusDonation(){

    $status=self::checkStatus();

      $update_fields = [
        'ID'          => $_POST['order_id'],
        'post_status' => $status,
        'edit_date'   => current_time( 'mysql' ),
      ];

      $updated = wp_update_post( apply_filters( 'give_update_payment_status_fields', $update_fields ) );
  }

  private static function checkStatus(){

      $status = $_POST['order_status'];
      return  self::$statusArray[$status]??self::$status;

  }

}