<?php
    /**
     * This filter hook is used to add configuration fields like api key, access token, oAuth button, etc.
     *
     * @since 2.5.0
     *
     * @return array
     */
    $settings = apply_filters( 'give_sensebank_add_configuration_fields', $settings );

    $settings['general'][] = [
      'name'          => esc_html__( 'Sensebank PayKey', 'sensebank-give' ),
      'desc'          => '',
      'wrapper_class' => 'give-sensebank-webhooks-tr',
      'id'            => 'sensebank_paykey',
      'type'          => 'sensebank_paykey',
    ];

    $settings['general'][] = [
      'name' => esc_html__( 'Sensebank Pay Key', 'sensebank-give' ),
      'desc' => esc_html__( 'In this option, you must specify the bank\'s payment key received during registration', 'sensebank-give' ),
      'id'   => 'sensebank_pay_key',
      'type' => 'text',
    ];